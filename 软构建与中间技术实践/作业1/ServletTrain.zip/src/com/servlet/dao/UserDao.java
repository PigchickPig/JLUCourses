package com.servlet.dao;

import java.sql.*;

import com.servlet.entity.User;

public class UserDao {

	 public final String DRIVER = "com.mysql.jdbc.Driver" ;
	 public final String URL = "jdbc:mysql://localhost:3306/javaee?useUnicode=true&characterEncoding=utf-8&useSSL=false";
	 public final String USER = "root";
	 public final String PWD = "123456" ;

	 protected Connection conn ;
	 protected Statement stmt;
	 protected PreparedStatement pstmt ;
	 protected ResultSet rs ;
	 
	 static User user=new User();
	 
	 static int updatecount=0;
	 
    protected Connection getConn(){
        try {
            //1.��������
            Class.forName(DRIVER);
            //2.ͨ��������������ȡ���Ӷ���
            return DriverManager.getConnection(URL,USER,PWD);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return null ;
    }

    protected void close(ResultSet rs , Statement stmt, PreparedStatement pstmt , Connection conn){
        try {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null){
            	stmt.close();
            }
            if (pstmt!=null){
                pstmt.close();
            }
            if (conn!=null && !conn.isClosed()){
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
	 
    public User getUser(String username, String password) throws SQLException {
    	String sql=null;
    	
    	sql="select * from user where username=? and password=?";
    	
    	
        try {
            conn = getConn();
            pstmt = conn.prepareStatement(sql);
           
            pstmt.setString(1,username);
            pstmt.setString(2,password);
            rs = pstmt.executeQuery();
            if(rs.next()){
            	System.out.println("rs��Ϊ��");
            	user.setId(rs.getInt(1));
             	user.setUsername(rs.getString(2));
             	user.setPassword(rs.getString(3));
             	return user;
            }else{
            	System.out.println("rsΪ��");
            }
        }
        	catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close(rs,stmt,pstmt,conn);
        }
        return null;
    }
    
    public Boolean UserExist(String username) throws SQLException {
    	String sql=null;
    	
    	sql="select * from user where username=?";
    	
    	
        try {
            conn = getConn();
            pstmt = conn.prepareStatement(sql);
           
            pstmt.setString(1,username);
            rs = pstmt.executeQuery();
            if(rs.next()){
            	System.out.println("user����");
             	return true;
            }else{
            	System.out.println("user������");
            }
        }
        	catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close(rs,stmt,pstmt,conn);
        }
        return false;
    }
    public Boolean AddUser(String username, String password) throws SQLException {
    	String sql=null;
    	
    	sql="insert into user(id,username,password)"+ "value(?,?,?)";
        try {
            conn = getConn();
            
            stmt=conn.createStatement();
        	rs=stmt.executeQuery("select * from user");	
        	rs.last();
        	
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, rs.getRow()+1);
            pstmt.setString(2,username);
            pstmt.setString(3,password);
            
            updatecount = pstmt.executeUpdate();
            if(updatecount!=0){
            	System.out.println("���³ɹ�");
             	return true;
            }else{
            	System.out.println("����ʧ��");
            }
        }
        	catch (SQLException e) {
            e.printStackTrace();
        } finally {
            close(rs,stmt,pstmt,conn);
        }
        return false;
    }
}
