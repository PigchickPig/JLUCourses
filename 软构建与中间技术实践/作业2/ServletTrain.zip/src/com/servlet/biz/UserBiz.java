package com.servlet.biz;

import java.sql.SQLException;

import com.servlet.dao.UserDao;
import com.servlet.entity.User;

public class UserBiz {
	static UserDao userDao = new UserDao();
    public User getUser(String username, String password){
        User  user = null;
        try {
            user  = userDao.getUser(username,password);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return user;
    }
    
    public Boolean checkUsername(String username){
        try {
            return userDao.checkUsername(username);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return false;
    }
    
    public Boolean checkpassword(String username, String password){
        try {
            return userDao.checkPassword(username, password);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return false;
    }
    
    public Boolean addUser(String username,String password){
    	try{
    		return userDao.addUser(username,password);
    	}catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    	return false;
    }
}
